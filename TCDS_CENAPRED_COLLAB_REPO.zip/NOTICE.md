Custodio del marco TCDS: Genaro Carrasco Ozuna (ORCID 0009-0005-6358-9910).
