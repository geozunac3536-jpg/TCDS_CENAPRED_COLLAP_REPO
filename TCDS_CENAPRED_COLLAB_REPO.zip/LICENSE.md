CC BY-NC-SA 4.0 (plantilla) — datos de terceros según `license` en cada packet.
