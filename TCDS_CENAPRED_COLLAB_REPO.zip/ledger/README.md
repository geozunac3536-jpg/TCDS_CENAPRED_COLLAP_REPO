Ledger append-only (hash chain). `ledger.jsonl` se crea al ingerir.
