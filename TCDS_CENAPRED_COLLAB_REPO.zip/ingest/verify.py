#!/usr/bin/env python3
import argparse, json, hashlib
from pathlib import Path
from jsonschema import Draft202012Validator

SCHEMA_PATH = Path(__file__).resolve().parents[1] / "schema" / "data_packet.schema.json"

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--packet", required=True)
    args = ap.parse_args()

    p = Path(args.packet)
    raw = p.read_bytes()
    pkt = json.loads(raw.decode("utf-8"))

    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    v = Draft202012Validator(schema)
    errs = sorted(v.iter_errors(pkt), key=lambda e: e.path)
    if errs:
        print("❌ Schema FAIL")
        for e in errs[:20]:
            print(" -", "/".join(map(str,e.path)), ":", e.message)
        return 2

    calc = sha256_bytes(raw)
    declared = str(pkt.get("integrity", {}).get("sha256_packet","")).lower()
    if declared and declared != ("0"*64) and declared != calc:
        print("❌ Hash mismatch")
        print(" declared:", declared)
        print(" calc    :", calc)
        return 3

    print("✅ Packet OK")
    print("sha256_packet:", calc)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
