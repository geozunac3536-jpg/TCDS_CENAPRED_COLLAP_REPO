#!/usr/bin/env python3
import argparse, json, hashlib
from pathlib import Path
from datetime import datetime, timezone
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "schema" / "data_packet.schema.json"
LEDGER_DIR = ROOT / "ledger"
LEDGER_PATH = LEDGER_DIR / "ledger.jsonl"

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def validate(pkt: dict):
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    v = Draft202012Validator(schema)
    errs = sorted(v.iter_errors(pkt), key=lambda e: e.path)
    if errs:
        msgs = [{"path": "/".join(map(str,e.path)), "msg": e.message} for e in errs]
        raise ValueError(json.dumps(msgs, ensure_ascii=False))

def prev_hash() -> str:
    if not LEDGER_PATH.exists():
        return "0"*64
    last = None
    with LEDGER_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if line: last=line
    if not last:
        return "0"*64
    return json.loads(last).get("entry_hash","0"*64)

def append(entry: dict):
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    with LEDGER_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--packet", required=True)
    ap.add_argument("--store", default=str(ROOT/"data/incoming"))
    args = ap.parse_args()

    pkt_path = Path(args.packet)
    raw = pkt_path.read_bytes()
    pkt = json.loads(raw.decode("utf-8"))
    validate(pkt)

    sha_pkt = sha256_bytes(raw)
    pkt.setdefault("integrity", {})
    pkt["integrity"]["sha256_packet"] = sha_pkt

    ph = prev_hash()
    issued = now_utc()
    entry_hash = sha256_bytes((ph + sha_pkt + issued).encode("utf-8"))

    entry = {"issued_utc": issued, "packet_id": pkt.get("packet_id"),
             "sha256_packet": sha_pkt, "prev": ph, "entry_hash": entry_hash}
    append(entry)

    store_dir = Path(args.store); store_dir.mkdir(parents=True, exist_ok=True)
    out_pkt = store_dir / f"{pkt['packet_id']}.json"
    out_rcp = store_dir / f"{pkt['packet_id']}.receipt.json"
    out_pkt.write_text(json.dumps(pkt, indent=2, ensure_ascii=False), encoding="utf-8")
    receipt = {"receipt_version":"0.1.0","issued_utc":issued,"packet_id":pkt["packet_id"],
               "sha256_packet":sha_pkt,"prev_ledger_hash":ph,"entry_hash":entry_hash}
    out_rcp.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")

    print("✅ Ingest OK")
    print("packet :", out_pkt)
    print("receipt:", out_rcp)
    print("entry_hash:", entry_hash)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
